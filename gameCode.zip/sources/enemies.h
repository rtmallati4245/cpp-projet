#pragma once 
#include "entity.h"
#include <SFML/Graphics.hpp>
#include <vector>

struct enemies : public Entity {
    sf::RectangleShape ghost;
    float speed  = 50.f;
    bool  alive  = true;
    float health = 2;
};

// ── BOSS ─────────────────────────────────────────────────────────────────────
struct Boss : public Entity {
    sf::RectangleShape body;          // collision & position 
    sf::Texture        texture;
    sf::Sprite         visualSprite;  
    float speed  = 180.f;
    bool  alive  = true;
    float health = 10;

    // animation
    int   frameCount   = 8;
    int   frameWidth   = 0;
    int   frameHeight  = 0;
    int   currentFrame = 0;
    float frameTimer   = 0.f;
    float frameSpeed   = 0.1f;

    // health-bar 
    sf::RectangleShape barBg;
    sf::RectangleShape barFg;
};


void updateEnemy(enemies &e, float dt, std::vector<sf::RectangleShape> &collisionBoxes);
void updateBoss (Boss    &b, float dt, std::vector<sf::RectangleShape> &collisionBoxes);
void animateBoss(Boss    &b, float dt);