#pragma once
#include <SFML/Graphics.hpp>

struct Bullet {
    sf::RectangleShape shape;
    float speed  = 700.f;
    bool  active = true;
};