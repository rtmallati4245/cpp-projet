#pragma once
#include <SFML/Graphics.hpp>
#include <vector>

class Entity {
public:
    bool  onGround = false;
    float yvel     = 0.f;
    float xvel     = 0.f;
    float gravity  = 980.f;

    virtual ~Entity() = default;
};