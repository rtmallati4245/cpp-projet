#pragma once
#include "entity.h"
#include <SFML/Graphics.hpp>
#include <vector>

class PlayerClass : public Entity {
public:
    float jumpStrength = -500.f;
    float speed        = 200.f;
    bool  faceRight    = true;
    float animTimer    = 0.f;
    int   frame        = 0;

    PlayerClass();

    void update(bool space, bool left, bool right, float dt,
                sf::Sprite &playerObj,
                std::vector<sf::RectangleShape> &collisionBoxes);
};