#include "player.h"
#include <algorithm>

PlayerClass::PlayerClass() {}

void PlayerClass::update(bool space, bool left, bool right, float dt, sf::Sprite &playerObj, std::vector<sf::RectangleShape> &collisionBoxes) {
    if (right) {
        xvel = speed;
        faceRight = true;
    } else if (left) {
        xvel = -speed;
        faceRight = false;
    } else {
        xvel = 0.f;
    }

    if (!onGround)
        yvel += gravity * dt;

    if (space && onGround) {
        yvel = jumpStrength;
        onGround = false;
    }

    playerObj.move(xvel * dt, yvel * dt);

    onGround = false;
    float groundLevel = 15 * 36.f;
    if (playerObj.getPosition().y + playerObj.getGlobalBounds().height > groundLevel) {
        playerObj.setPosition(playerObj.getPosition().x, groundLevel - playerObj.getGlobalBounds().height);
        yvel = 0.f;
        onGround = true;
    }

    for (auto& box : collisionBoxes) {
        sf::FloatRect playerBounds = playerObj.getGlobalBounds();
        sf::FloatRect boxBounds    = box.getGlobalBounds();

        if (playerBounds.intersects(boxBounds)) {
            float overlapLeft   = (playerBounds.left + playerBounds.width) - boxBounds.left;
            float overlapRight  = (boxBounds.left + boxBounds.width) - playerBounds.left;
            float overlapTop    = (playerBounds.top + playerBounds.height) - boxBounds.top;
            float overlapBottom = (boxBounds.top + boxBounds.height) - playerBounds.top;

            float minOverlap = std::min({overlapLeft, overlapRight, overlapTop, overlapBottom});

            if (minOverlap == overlapTop && yvel >= 0.f) {
                playerObj.setPosition(playerBounds.left, boxBounds.top - playerBounds.height);
                yvel = 0.f;
                onGround = true;
            } else if (minOverlap == overlapBottom && yvel < 0.f) {
                playerObj.setPosition(playerBounds.left, boxBounds.top + boxBounds.height);
                yvel = 0.f;
            } else if (minOverlap == overlapLeft) {
                playerObj.setPosition(boxBounds.left - playerBounds.width, playerBounds.top);
            } else if (minOverlap == overlapRight) {
                playerObj.setPosition(boxBounds.left + boxBounds.width, playerBounds.top);
            }
        }
    }

    sf::Vector2f pos = playerObj.getPosition();
    if (pos.x < 0.f) playerObj.setPosition(0.f, pos.y);
    if (pos.x > 6000.f) playerObj.setPosition(6000.f, pos.y);
    if (pos.y < 0.f) { playerObj.setPosition(pos.x, 0.f); yvel = 0.f; }

    if (xvel != 0.f) {
        animTimer += dt;
        if (animTimer >= 0.15f) {
            frame = (frame + 1) % 6;
            animTimer = 0.f;
        }
    } else {
        frame = 0;
        animTimer = 0.f;
    }

    playerObj.setTextureRect(sf::IntRect(frame * 32, 0, 32, 32));
}