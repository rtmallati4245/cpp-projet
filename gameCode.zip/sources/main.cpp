#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <set>
#include <algorithm> 
#include "player.h"
#include "enemies.h"
#include "bullet.h"

using namespace sf;
using namespace std;

int main() {
    RenderWindow window(VideoMode(1280, 720), "game");
    window.setFramerateLimit(120);

    Texture playerSheet;
    if (!playerSheet.loadFromFile("images/gun-walk/gun-walk.png"))
        cout << "Error loading spritesheet!" << endl;

    Sprite player(playerSheet);
    player.setTextureRect(IntRect(0, 0, 32, 32));
    player.setScale(2.f, 2.f);

    PlayerClass pObject;

    Texture platformTexture;
    platformTexture.loadFromFile("images/mapv01.png");
    Sprite platform(platformTexture);

    float mapScale = 720.f / 640.f;  
    platform.setScale(mapScale, mapScale);

    float tileSize = 32.f * mapScale;  
    float mapWidth = 4800.f * mapScale;
    float mapHeight = 720.f;

    vector<RectangleShape> collisionBoxes;

    ifstream file("assets/map_solid.csv");
    if (!file.is_open()) {
        cout << "cant open map_solid.csv" << endl;
    } else {
        cout << "map_solid.csv opened ok" << endl;
        string line;
        int row = 0;
        while (getline(file, line)) {
            stringstream ss(line);
            string cell;
            int col = 0;
            while (getline(ss, cell, ',')) {
                int tileID = stoi(cell);
                if (tileID == 1) {
                    RectangleShape box(Vector2f(tileSize, tileSize));
                    box.setPosition(col * tileSize, row * tileSize);
                    collisionBoxes.push_back(box);
                }
                col++;
            }
            row++;
        }
        cout << "total boxes: " << collisionBoxes.size() << endl;
    }

    float spawnY = 13 * tileSize - 64.f;
    player.setPosition(3 * tileSize, spawnY);

    vector<Bullet> bulletList;
    bool shootPressed = false;
    bool gameOver = false;
    bool gameWon  = false;
    int  enemiesKilled = 0;

// Vague 1 → Vague 2 → Boss → Win/Lose
    enum class GamePhase { WAVE1, WAVE2, BOSS, DONE };
    GamePhase phase = GamePhase::WAVE1;

    bool wave2Spawned = false;
    bool bossSpawned  = false;   
    

    vector<float> startX = {800.f, 1200.f, 1600.f};
    vector<enemies> enemyList;
    for (float x : startX) {
        enemies e;
        e.ghost.setSize(Vector2f(tileSize, tileSize));
        e.ghost.setFillColor(Color(0, 139, 139));
        e.ghost.setPosition(x, spawnY);
        enemyList.push_back(e);
    }

    // boss object (deja construte, activated when phase == BOSS) 
    Boss boss;
    if (!boss.texture.loadFromFile("images/werewolf-run.png"))
        cout << "Error loading boss spritesheet!" << endl;

    //animation boss
    boss.frameWidth  = boss.texture.getSize().x / boss.frameCount;
    boss.frameHeight = boss.texture.getSize().y;

    // collision body 
    boss.body.setSize(Vector2f(tileSize * 2.f, tileSize * 2.f));
    boss.body.setFillColor(Color::Transparent);
    float bossGroundLevel = 15 * 36.f;
    boss.body.setPosition(4727.46f, bossGroundLevel - tileSize * 2.f);

    boss.visualSprite.setTexture(boss.texture);
    boss.visualSprite.setTextureRect(IntRect(0, 0, boss.frameWidth, boss.frameHeight));
    float bossVisScaleX = (tileSize * 2.f) / boss.frameWidth;
    float bossVisScaleY = (tileSize * 2.f) / boss.frameHeight;
    boss.visualSprite.setScale(-bossVisScaleX, bossVisScaleY);  // negative = flip left
    boss.visualSprite.setOrigin(float(boss.frameWidth), 0.f);

    // health bar 
    const float BAR_W = 300.f, BAR_H = 20.f;
    boss.barBg.setSize(Vector2f(BAR_W, BAR_H));
    boss.barBg.setFillColor(Color(80, 80, 80));
    boss.barBg.setPosition(490.f, 30.f);   //centre

    boss.barFg.setSize(Vector2f(BAR_W, BAR_H));
    boss.barFg.setFillColor(Color(200, 20, 20));
    boss.barFg.setPosition(490.f, 30.f);


    sf::Font font;
    font.loadFromFile("assets/gameFont.ttf");

    sf::Text gameOverText;
    gameOverText.setFont(font);
    gameOverText.setString("GAME OVER\nPress Enter to restart");
    gameOverText.setCharacterSize(50);
    gameOverText.setFillColor(Color::White);
    gameOverText.setOrigin(gameOverText.getLocalBounds().width / 2.f, gameOverText.getLocalBounds().height / 2.f);
    gameOverText.setPosition(640.f, 360.f);

    sf::Text ggText;
    ggText.setFont(font);
    ggText.setString("GG! Press Enter to play again");
    ggText.setCharacterSize(30);
    ggText.setFillColor(Color::Yellow);
    ggText.setOrigin(ggText.getLocalBounds().width / 2.f, ggText.getLocalBounds().height / 2.f);
    ggText.setPosition(640.f, 360.f);

    sf::Text bossWarning;
    bossWarning.setFont(font);
    bossWarning.setString("!! BOSS !!");
    bossWarning.setCharacterSize(60);
    bossWarning.setFillColor(Color::Red);
    bossWarning.setOrigin(bossWarning.getLocalBounds().width / 2.f, bossWarning.getLocalBounds().height / 2.f);
    bossWarning.setPosition(640.f, 150.f);
    float bossWarningTimer = 0.f;

    sf::Text About;
    About.setFont(font);
    About.setString("Mini projet\n\nModule: POO avec C++\n\nCree par: REDA , ABDALLAH!\n\n Controls: A/D to move, Space to jump, F to shoot");
    About.setCharacterSize(20);
    About.setFillColor(Color::Yellow);
    About.setOrigin(About.getLocalBounds().width / 2.f, About.getLocalBounds().height / 2.f);
    About.setPosition(640.f, 360.f);

    Texture mainMenuTexture;
    mainMenuTexture.loadFromFile("images/main.png");
    Sprite menuSprite(mainMenuTexture);
    menuSprite.setScale(1280.f / mainMenuTexture.getSize().x, 720.f / mainMenuTexture.getSize().y);

    bool inMenu  = true;
    bool inAbout = false;

    Texture aboutText;
    aboutText.loadFromFile("images/main.png");
    Sprite aboutSprite(aboutText);
    aboutSprite.setScale(1280.f / aboutText.getSize().x, 720.f / aboutText.getSize().y);

    vector<string> options = {"START", "ABOUT", "QUIT"};
    vector<Text> menuTexts;

    for (int i = 0; i < 3; i++) {
        Text t;
        t.setFont(font);
        t.setString(options[i]);
        t.setCharacterSize(40);
        t.setFillColor(Color::White);
        t.setOrigin(t.getLocalBounds().width / 2.f, t.getLocalBounds().height / 2.f);
        t.setPosition(640.f, 300.f + i * 80);
        menuTexts.push_back(t);
    }

    int selected = 0;
    menuTexts[selected].setFillColor(Color::Yellow);

    sf::Text logoText;
    logoText.setFont(font);
    logoText.setString("NO MAN'S LAND");
    logoText.setCharacterSize(80);
    logoText.setFillColor(Color::Red);
    logoText.setStyle(sf::Text::Bold);
    logoText.setOrigin(logoText.getLocalBounds().width / 2.f, logoText.getLocalBounds().height / 2.f);
    logoText.setPosition(640.f, 160.f);



    sf::View camera(sf::FloatRect(0.f, 0.f, 1280.f, 720.f));
    Clock clock;

    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();

        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();

            if (inMenu && event.type == Event::KeyPressed) {
                if (event.key.code == Keyboard::Up) {
                    menuTexts[selected].setFillColor(Color::White);
                    selected = (selected - 1 + 3) % 3;
                    menuTexts[selected].setFillColor(Color::Yellow);
                }
                if (event.key.code == Keyboard::Down) {
                    menuTexts[selected].setFillColor(Color::White);
                    selected = (selected + 1) % 3;
                    menuTexts[selected].setFillColor(Color::Yellow);
                }
                if (event.key.code == Keyboard::Enter) {
                    if (selected == 0)      inMenu = false;
                    else if (selected == 1) { inMenu = false; inAbout = true; }
                    else if (selected == 2)  window.close();
                }
            }
         }

        if (inMenu) {
            window.clear();
            window.draw(menuSprite);
            window.draw(logoText);
            for (auto& t : menuTexts) window.draw(t);
            window.display();
            continue;
        }

        if (inAbout) {
            window.clear();
            window.draw(aboutSprite);
            window.draw(About);
            window.display();
            if (Keyboard::isKeyPressed(Keyboard::Escape)) { inAbout = false; inMenu = true; }
            continue;
        }
// camera follows player
        float camX = player.getPosition().x - 640.f;
        if (camX < 0.f)               camX = 0.f;
        if (camX > mapWidth - 1280.f) camX = mapWidth - 1280.f;
        camera.setCenter(camX + 640.f, 360.f);
        window.setView(camera);

        bool right = Keyboard::isKeyPressed(Keyboard::D);
        bool left  = Keyboard::isKeyPressed(Keyboard::Q);
        bool space = Keyboard::isKeyPressed(Keyboard::Space);
        bool shoot = Keyboard::isKeyPressed(Keyboard::F);
       
        if (!gameOver && !gameWon) {
            pObject.update(space, left, right, dt, player, collisionBoxes);

            if (pObject.faceRight) { player.setScale(2.f,  2.f); player.setOrigin(0.f,  0.f); }
            else                   { player.setScale(-2.f, 2.f); player.setOrigin(32.f, 0.f); }


            for (auto& e : enemyList)
                updateEnemy(e, dt, collisionBoxes);

            if (phase == GamePhase::BOSS && boss.alive) {
                updateBoss(boss, dt, collisionBoxes);
                animateBoss(boss, dt);
                if (bossWarningTimer > 0.f) bossWarningTimer -= dt;

                float ratio = boss.health / 10.f;
                if (ratio < 0.f) ratio = 0.f;
                boss.barFg.setSize(Vector2f(BAR_W * ratio, BAR_H));
            }

            // ── shooting ──────────────────────────────────────────────────────
            if (shoot && !shootPressed) {
                Bullet b;
                b.shape.setSize(Vector2f(10.f, 4.f));
                b.shape.setFillColor(Color::Yellow);
                b.shape.setPosition(player.getPosition().x, player.getPosition().y + 10.f);
                b.speed = pObject.faceRight ? 700.f : -700.f;
                bulletList.push_back(b);
            }
            shootPressed = shoot;

            for (auto& b : bulletList) {
                b.shape.move(b.speed * dt, 0.f);
                // Deactivate when bullet leaves the visible camera view
                sf::FloatRect view(camera.getCenter().x - 640.f, camera.getCenter().y - 360.f, 1280.f, 720.f);
                if (!view.intersects(b.shape.getGlobalBounds()))
                    b.active = false;

            //hit enemeis 3adyin
                for (auto& e : enemyList) {
                    if (b.active && b.shape.getGlobalBounds().intersects(e.ghost.getGlobalBounds())) {
                        e.health--;
                        b.active = false;
                        if (e.health <= 0) { e.alive = false; enemiesKilled++; }
                    }
                }

                // hit boss
                if (b.active && phase == GamePhase::BOSS && boss.alive &&
                    b.shape.getGlobalBounds().intersects(boss.body.getGlobalBounds())) {
                    boss.health--;
                    b.active = false;
                    if (boss.health <= 0) { boss.alive = false; phase = GamePhase::DONE; }
                }
            }

            bulletList.erase(remove_if(bulletList.begin(), bulletList.end(),
                [](Bullet& b){ return !b.active; }), bulletList.end());
            enemyList.erase(remove_if(enemyList.begin(), enemyList.end(),
                [](enemies& e){ return !e.alive; }), enemyList.end());

            // Wave 1 → Wave 2: all 3 starting enemies dead
            if (phase == GamePhase::WAVE1 && enemyList.empty() && !wave2Spawned) {
                wave2Spawned = true;
                phase = GamePhase::WAVE2;
                // spawn 3 enemies at playerX + 300, spread 200px apart
                float baseX = player.getPosition().x + 1100.f;
                for (int i = 0; i < 3; i++) {
                    enemies e;
                    e.ghost.setSize(Vector2f(tileSize, tileSize));
                    e.ghost.setFillColor(Color(0, 100, 180));   // blue tint to distinguish
                    e.ghost.setPosition(baseX + i * 200.f, spawnY);
                    enemyList.push_back(e);
                }
            }

            // Wave 2 → Boss: all wave-2 enemies dead
            if (phase == GamePhase::WAVE2 && enemyList.empty() && !bossSpawned) {
                bossSpawned  = true;
                phase        = GamePhase::BOSS;
                // reset boss position in case of restart
                boss.alive   = true;
                boss.health  = 10;
                boss.body.setPosition(4727.46f, 15 * 36.f - tileSize * 2.f);
                boss.barFg.setSize(Vector2f(BAR_W, BAR_H));
                bossWarningTimer = 3.f;   // show "!! BOSS !!" for 3 seconds
            }

            // Win: boss dead
            if (phase == GamePhase::DONE) gameWon = true;

            // ── player–enemy / player–boss contact = game over ────────────────
            for (auto& e : enemyList) {
                if (e.ghost.getGlobalBounds().intersects(player.getGlobalBounds()))
                    gameOver = true;
            }
            if (phase == GamePhase::BOSS && boss.alive &&
                boss.body.getGlobalBounds().intersects(player.getGlobalBounds()))
                gameOver = true;
        }

        // ── draw ──────────────────────────────────────────────────────────────
        window.clear();
        window.draw(platform);

      /*  for (auto& box : collisionBoxes) {
            RectangleShape debug = box;
            debug.setFillColor(Color(255, 0, 0, 80));
            window.draw(debug);
        }*/

        if (!gameOver && !gameWon) {
            for (auto& e : enemyList) window.draw(e.ghost);
            if (phase == GamePhase::BOSS && boss.alive) window.draw(boss.visualSprite);
            for (auto& b : bulletList) window.draw(b.shape);
            window.draw(player);
        }

        // ── UI (screen space) ─────────────────────────────────────────────────
        window.setView(window.getDefaultView());

        // boss health bar
        if (phase == GamePhase::BOSS && boss.alive) {
            window.draw(boss.barBg);
            window.draw(boss.barFg);
        }

        // boss warning flash
        if (bossWarningTimer > 0.f)
            window.draw(bossWarning);

        if (gameWon) {
            window.draw(ggText);
            if (Keyboard::isKeyPressed(Keyboard::Enter)) {
                // full reset
                gameWon = false; gameOver = false;
                enemiesKilled = 0;
                phase = GamePhase::WAVE1;
                wave2Spawned = false; bossSpawned = false;
                bossWarningTimer = 0.f;
                player.setPosition(3 * tileSize, spawnY);
                enemyList.clear(); bulletList.clear();
                // restore wave 1
                for (float x : startX) {
                    enemies e;
                    e.ghost.setSize(Vector2f(tileSize, tileSize));
                    e.ghost.setFillColor(Color(0, 139, 139));
                    e.ghost.setPosition(x, spawnY);
                    enemyList.push_back(e);
                }
                // reset boss
                boss.alive  = true; boss.health = 4;
                boss.body.setPosition(4353.13f, 15 * 36.f - tileSize * 2.f);
                boss.barFg.setSize(Vector2f(BAR_W, BAR_H));
            }
        } else if (gameOver) {
            window.draw(gameOverText);
            if (Keyboard::isKeyPressed(Keyboard::Enter)) {
                gameOver = false; enemiesKilled = 0;
                phase = GamePhase::WAVE1;
                wave2Spawned = false; bossSpawned = false;
                bossWarningTimer = 0.f;
                player.setPosition(3 * tileSize, spawnY);
                enemyList.clear(); bulletList.clear();
                for (float x : startX) {
                    enemies e;
                    e.ghost.setSize(Vector2f(tileSize, tileSize));
                    e.ghost.setFillColor(Color(0, 139, 139));
                    e.ghost.setPosition(x, spawnY);
                    enemyList.push_back(e);
                }
                boss.alive  = true; boss.health = 4;
                boss.body.setPosition(4727.46f, 15 * 36.f - tileSize * 2.f);
                boss.barFg.setSize(Vector2f(BAR_W, BAR_H));
            }
        }

        window.display();
    }
    return 0;
}
