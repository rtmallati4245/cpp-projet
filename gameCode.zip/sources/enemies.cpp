#include "enemies.h"
#include <iostream>
using namespace sf;
using namespace std;

// ── original enemy update (unchanged) ────────────────────────────────────────
void updateEnemy(enemies &e, float dt, vector<RectangleShape> &collisionBoxes) {
    e.xvel = -e.speed;

    if (!e.onGround)
        e.yvel += e.gravity * dt;

    e.ghost.move(e.xvel * dt, e.yvel * dt);

    float groundLevel = 15 * 36.f;
    if (e.ghost.getPosition().y + e.ghost.getGlobalBounds().height > groundLevel) {
        e.ghost.setPosition(e.ghost.getPosition().x, groundLevel - e.ghost.getGlobalBounds().height);
        e.yvel = 0.f;
        e.onGround = true;
    } else {
        e.onGround = false;
    }

    for (auto& box : collisionBoxes) {
        FloatRect enemyBounds = e.ghost.getGlobalBounds();
        FloatRect boxBounds   = box.getGlobalBounds();

        if (enemyBounds.intersects(boxBounds)) {
            float overlapLeft   = (enemyBounds.left + enemyBounds.width) - boxBounds.left;
            float overlapRight  = (boxBounds.left + boxBounds.width)     - enemyBounds.left;
            float overlapTop    = (enemyBounds.top + enemyBounds.height) - boxBounds.top;
            float overlapBottom = (boxBounds.top + boxBounds.height)     - enemyBounds.top;

            float minOverlap = std::min({overlapLeft, overlapRight, overlapTop, overlapBottom});

            if (minOverlap == overlapTop && e.yvel >= 0.f) {
                e.ghost.setPosition(enemyBounds.left, boxBounds.top - enemyBounds.height);
                e.yvel = 0.f;
                e.onGround = true;
            } else if (minOverlap == overlapBottom && e.yvel < 0.f) {
                e.ghost.setPosition(enemyBounds.left, boxBounds.top + boxBounds.height);
                e.yvel = 0.f;
            } else if (minOverlap == overlapLeft) {
                e.ghost.setPosition(boxBounds.left - enemyBounds.width, enemyBounds.top);
                e.yvel = -300.f;
            } else if (minOverlap == overlapRight) {
                e.ghost.setPosition(boxBounds.left + boxBounds.width, enemyBounds.top);
                e.yvel = -300.f;
            }
        }
    }

    Vector2f pos = e.ghost.getPosition();
    if (pos.x < 0.f) e.ghost.setPosition(0.f, pos.y);
    if (pos.y < 0.f) {
        e.ghost.setPosition(pos.x, 0.f);
        e.yvel = 0.f;
    }
}

// ── BOSS update — original b.body collision logic, untouched ────────────────
void updateBoss(Boss &b, float dt, vector<RectangleShape> &collisionBoxes) {
    b.xvel = -b.speed;

    if (!b.onGround)
        b.yvel += b.gravity * dt;

    b.body.move(b.xvel * dt, b.yvel * dt);

    float groundLevel = 15 * 36.f;
    if (b.body.getPosition().y + b.body.getGlobalBounds().height > groundLevel) {
        b.body.setPosition(b.body.getPosition().x, groundLevel - b.body.getGlobalBounds().height);
        b.yvel     = 0.f;
        b.onGround = true;
    } else {
        b.onGround = false;
    }

    for (auto& box : collisionBoxes) {
        FloatRect bb = b.body.getGlobalBounds();
        FloatRect bx = box.getGlobalBounds();

        if (!bb.intersects(bx)) continue;

        float overlapLeft   = (bb.left + bb.width) - bx.left;
        float overlapRight  = (bx.left + bx.width) - bb.left;
        float overlapTop    = (bb.top  + bb.height) - bx.top;
        float overlapBottom = (bx.top  + bx.height) - bb.top;

        float minOverlap = std::min({overlapLeft, overlapRight, overlapTop, overlapBottom});

        if (minOverlap == overlapTop && b.yvel >= 0.f) {
            b.body.setPosition(bb.left, bx.top - bb.height);
            b.yvel     = 0.f;
            b.onGround = true;
        } else if (minOverlap == overlapBottom && b.yvel < 0.f) {
            b.body.setPosition(bb.left, bx.top + bx.height);
            b.yvel = 0.f;
        }

    }

    Vector2f pos = b.body.getPosition();
    if (pos.x < 0.f) b.body.setPosition(0.f, pos.y);
    if (pos.y < 0.f) {
        b.body.setPosition(pos.x, 0.f);
        b.yvel = 0.f;
    }
}

// ── BOSS animation
void animateBoss(Boss &b, float dt) {
    b.frameTimer += dt;
    if (b.frameTimer >= b.frameSpeed) {
        b.frameTimer = 0.f;
        b.currentFrame = (b.currentFrame + 1) % b.frameCount;
    }

    b.visualSprite.setTextureRect(sf::IntRect(
        b.currentFrame * b.frameWidth, 0,
        b.frameWidth, b.frameHeight
    ));


    FloatRect hb = b.body.getGlobalBounds();
    FloatRect vs = b.visualSprite.getGlobalBounds();
    b.visualSprite.setPosition(
        hb.left - (vs.width  - hb.width)  / 2.f,
        hb.top  - (vs.height - hb.height) / 2.f
    );
}